package com.omer.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnDise: Button =findViewById(R.id.button)
        btnDise.setOnClickListener() {
            rollDise()
        }
        rollDise()
    }
    fun rollDise(){
        val image:ImageView=findViewById(R.id.imageView2)
        val dice=Dice(6)
        val rolleDice=dice.roll()

        val turnedImage = when(rolleDice){
            1->R.drawable.dice1
            2->R.drawable.dice2
            3->R.drawable.dice3
            4->R.drawable.dice4
            5->R.drawable.dice5
            else->R.drawable.dice6

        }
        image.setImageResource(turnedImage as Int)

    }
}

    class Dice(val numSize:Int){
        fun roll():Int{
            return (1..numSize).random()
        }
    }